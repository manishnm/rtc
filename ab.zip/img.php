<?php
  $a = $_GET['img'];
  echo " " . $a;
 ?>